"""Compact, bounded-compute continuation."""
