"""Reproducible earthquake classification experiments."""
